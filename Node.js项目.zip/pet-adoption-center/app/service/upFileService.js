const Service = require('egg').Service;
class upFileService extends Service {
    async upPhoto(photo, username){
        
        console.log(photo, username);
        let sql = 'update userinf set photo = ? where name = ?';
        let result = await this.ctx.app.mysql.query(sql, [photo, username]);
        return result;
    }
    async lunbo(url) {
        let sql = 'insert into lunbo(url) values(?)';
        let result = await this.ctx.app.mysql.query(sql, [url]);
        return result;
    }
    async baike(name, content) {
        let sql = 'insert into animal(name, content) values(?,?)';
        let result = await this.ctx.app.mysql.query(sql, [name, content]);
        return result;
    }
}
module.exports = upFileService;