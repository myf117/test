const animalController = require('../controller/animalController');

const Service = require('egg').Service;
class animalService extends Service{
    async showAllAnimal(){
        let sql = 'select * from animal limit 6';
        let list = await this.ctx.app.mysql.query(sql, []);
        // console.log(list);
        return list;
    }
    async likeAnimal(name){
        console.log(name);
        let sql = "select * from animal where name like ? limit 6";
        let list = await this.ctx.app.mysql.query(sql, [`%${name}`]);
        // console.log(list);
        return list;
    }
}
module.exports = animalService;