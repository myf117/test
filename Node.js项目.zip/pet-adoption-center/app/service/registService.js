const Service = require('egg').Service;
class registService extends Service {
    async regist(username, pwd, tell, address, sex) {
        let result = null;
        let sql1 = 'select * from userdata where username = ?';
        let re1 = await this.ctx.app.mysql.query(sql1, [username]);
        if (re1.length) {
            result = '用户名已经存在';
            return result;
        } else {
            let sql2 = 'insert into userdata(username, pwd, tell) values(?,?,?)';
            await this.ctx.app.mysql.query(sql2, [username, pwd, tell]);
            let sql3 = 'insert into userinf(name, pwd, sex, address, tell) values(?,?,?,?,?)';
            await this.ctx.app.mysql.query(sql3, [username, pwd, sex, address, tell]);
            result = '可以注册';
            return result;

        }
    }
}
module.exports = registService;