
const Service = require('egg').Service;
class livingService extends Service{
    async insertLive(adopt_id, username){
        let sql1 = 'select * from live where adopt_id = ?';
        let list = await this.ctx.app.mysql.query(sql1, [adopt_id]);
        if(list.length == 0){
            let sql2 = 'select title, upuser, timer from adopt where id = ?';
            let list2 = await this.ctx.app.mysql.query(sql2, [adopt_id]);
            let sql3 = 'insert into live(title,upuser,adopt_id,timer,username) values(?,?,?,?,?)';
            let result = await this.ctx.app.mysql.query(sql3, [list2[0].title, list2[0].upuser, adopt_id, list2[0].timer, username]);
            return result;
        }
    }
    async selectLive(username) {
        let sql = 'select * from live where username = ?';
        let list = await this.ctx.app.mysql.query(sql, [username]);
        return list;
    }
    async delLive(id){
        let sql = 'delete from live where id = ?';
        let result = await this.ctx.app.mysql.query(sql, [id]);
        return result;
    }
}
module.exports = livingService;