const Service = require('egg').Service;
class loginService extends Service{
    async login(usename, pwd){
        let logSql = 'select * from userdata where username = ? and pwd = ?';
        let logList = await this.ctx.app.mysql.query(logSql, [usename, pwd]);
        return logList;
    }
}
module.exports = loginService;