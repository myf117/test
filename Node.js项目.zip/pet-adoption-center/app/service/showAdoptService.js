const Service = require('egg').Service;
class showAdoptService extends Service{
    async show(){
        let sql = 'select * from adopt limit 5';
        let list = await this.ctx.app.mysql.query(sql,[]);
        return list;
    }
    async more(){
        let sql = 'select * from adopt';
        let list = await this.ctx.app.mysql.query(sql, []);
        return list;
    }
    async user(name){

        let sql = 'select id from userinf where name = ?';
        let list = await this.ctx.app.mysql.query(sql, [name]);
        return list;
    }
    async news(){
        let sql = 'select * from  news';
        let list = await this.ctx.app.mysql.query(sql, []);
        return list;
    }
    async getLunbosrc(){
        let sql = 'select * from lunbo';
        let list = await this.ctx.app.mysql.query(sql,[]);
        return list;
    }
}
module.exports = showAdoptService;