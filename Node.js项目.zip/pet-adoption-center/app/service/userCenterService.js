const Service = require('egg').Service;
class userCenterService extends Service {
    async myInf(name){
        console.log(name);
        let sql = 'select * from userinf where name = ?';
        let list = await this.ctx.app.mysql.query(sql, [name]);
        console.log(list);
        return list;
    }
    async myBlog(upuser){
        let sql = 'select * from adopt where upuser = ?';
        let list = await this.ctx.app.mysql.query(sql, [upuser]);
        return list;
    }
    async modify(username, pwd){
        console.log(pwd);
        let sql1 = 'update userData set pwd = ? where username = ?';
        await this.ctx.app.mysql.query(sql1, [pwd, username]);
        let sql2 = 'update userinf set pwd = ? where name = ?';
        await this.ctx.app.mysql.query(sql2, [pwd, username]);
        return '修改成功';
    }
    async upBlog(title, upuser, content, timer, looker){
        console.log(upuser);
        let sql = 'insert into adopt(title, upuser, content, timer, looker) values(?,?,?,?,?)';
        let result = await this.ctx.app.mysql.query(sql,[title, upuser, content, timer, looker]);
        return result;
    }
}
module.exports = userCenterService;