const Service = require('egg').Service;
class adoptContentService extends Service{
    async content(id){
        let sql = 'select title, upuser, content, looker, timer from adopt where id = ?;';
        let list = await this.ctx.app.mysql.query(sql, [id]);
        return list;
    }
    async looker(id, looker){
        let sql2 = 'update adopt set looker = ? where id = ?';
        looker = Number(looker);
        let result = await this.ctx.app.mysql.query(sql2, [looker + 1, id]);
        return result;
    }
    async message(id, title){
        let sql = 'select name, timer, content from usermessage where user_id = ? and blogtitle = ?';
        let list = await this.ctx.app.mysql.query(sql, [id, title]);
        return list;
    }
    async upMessage(name, timer, content, user_id){
        // user_id = Number(user_id);
        let sql1 = 'select title from adopt where id = ?';
        let list1 = await this.ctx.app.mysql.query(sql1, [user_id]);
        let sql2 = 'insert into usermessage(name, timer, content, user_id, blogtitle) values(?,?,?,?,?)';
        await this.ctx.app.mysql.query(sql2, [name, timer, content, user_id, list1[0].title]);
        return list1;
    }
}
module.exports = adoptContentService;