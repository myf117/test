const Controller = require('egg').Controller;
class livingController extends Controller{
    async insertLive(){
        let id = this.ctx.request.query.aId;
        let username = this.ctx.request.query.username;
        let result = await this.ctx.service.livingService.insertLive(id, username);
        this.ctx.response.body = result;
    }
    async selectLive(){
        let username = this.ctx.request.query.username;
        let result = await this.ctx.service.livingService.selectLive(username);
        this.ctx.response.body = result;
    }
    async delLive(){
        let id = this.ctx.request.query.lId;
        let result = await this.ctx.service.livingService.delLive(id);
        this.ctx.response.body = result;
    }
}
module.exports = livingController;