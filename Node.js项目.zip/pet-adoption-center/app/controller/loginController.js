const Controller = require('egg').Controller;
class loginController extends Controller{
    async login(){
        let username = this.ctx.request.body.username;
        let pwd = this.ctx.request.body.pwd;
        let result = await this.ctx.service.loginService.login(username, pwd);
        this.ctx.response.body = result;
    }
}
module.exports = loginController;