const Controller = require('egg').Controller;
class userCenterController extends Controller {
    async myInf(){
        let name = this.ctx.request.query.name;
        let result = await this.ctx.service.userCenterService.myInf(name);
        this.ctx.response.body = result;
    }
    async myBlog(){
        let upuser = this.ctx.request.query.upuser;
        let result = await this.ctx.service.userCenterService.myBlog(upuser);
        this.ctx.response.body = result;
    }
    async modify(){
        let username = this.ctx.request.query.username;
        let pwd = this.ctx.request.query.pwd;
        console.log(username, pwd);
        let result = await this.ctx.service.userCenterService.modify(username,pwd);
        this.ctx.response.body = result;
    }
    async upBlog(){
        let title = this.ctx.request.body.title;
        let upuser = this.ctx.request.body.upuser;
        let content = this.ctx.request.body.content;
        let timer = this.ctx.request.body.timer;
        let looker = this.ctx.request.body.looker;
        let result = await this.ctx.service.userCenterService.upBlog(title, upuser, content, timer, looker);
        this.ctx.response.body = result;
    }
}
module.exports = userCenterController;