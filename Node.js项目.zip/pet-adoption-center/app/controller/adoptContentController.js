const Controller = require('egg').Controller;
class adoptContentController extends Controller{
    async content(){
        let id = this.ctx.request.query.id;
        let result = await this.ctx.service.adoptContentService.content(id);
        this.ctx.response.body = result;
    }
    async looker(){
        let id = this.ctx.request.query.id;
        let looker = this.ctx.request.query.looker;
        let result = await this.ctx.service.adoptContentService.looker(id, looker);
        this.ctx.response.body = result;
    }
    async message(){
        let id = this.ctx.request.query.id;
        let title = this.ctx.request.query.title;
        let result = await this.ctx.service.adoptContentService.message(id,title);
        this.ctx.response.body = result;
    }
    async upMessage(){
        let name = this.ctx.request.query.name;
        let timer = this.ctx.request.query.timer;
        let content = this.ctx.request.query.content;
        let user_id = this.ctx.request.query.user_id;
        console.log(name, timer, content, user_id);
        let result = await this.ctx.service.adoptContentService.upMessage(name, timer, content, user_id);
        this.ctx.response.body = result;
        console.log(result);
    }
}
module.exports = adoptContentController;