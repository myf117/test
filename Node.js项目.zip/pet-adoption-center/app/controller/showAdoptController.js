const Controller = require('egg').Controller;
class showAdoptController extends Controller{
    async show(){
        let result = await this.ctx.service.showAdoptService.show();
        this.ctx.response.body = result;
    }
    async more(){
        let result = await this.ctx.service.showAdoptService.more();
        this.ctx.response.body = result;
    }
    async user(){
        let name = this.ctx.request.query.name;
        let result = await this.ctx.service.showAdoptService.user(name);
        this.ctx.response.body = result;
    }
    async news(){
        let result = await this.ctx.service.showAdoptService.news();
        this.ctx.response.body = result;
    }
    async getLunbosrc(){
        let result = await this.ctx.service.showAdoptService.getLunbosrc();
        this.ctx.response.body = result;
    }
}
module.exports = showAdoptController;