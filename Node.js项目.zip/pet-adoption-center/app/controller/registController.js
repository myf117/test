const Controller = require('egg').Controller;
class registController extends Controller{
    async regist(){
        // let table = this.ctx.request.query.table;
        console.log(this.ctx.request.body);
        let username = this.ctx.request.body.username;
        let pwd = this.ctx.request.body.pwd;
        let tell = this.ctx.request.body.tell;
        let address = this.ctx.request.body.address;
        let sex = this.ctx.request.body.sex;
        console.log(1);
        let result = await this.ctx.service.registService.regist(username, pwd, tell, address, sex);
        console.log(result);
        this.ctx.response.body = result;
    }
}
module.exports = registController;