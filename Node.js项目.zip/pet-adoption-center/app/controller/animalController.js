const Controller = require('egg').Controller;
class animalController extends Controller{
    async showAllAnimal(){
        let result = await this.ctx.service.animalService.showAllAnimal();
        this.ctx.response.body = result;
    }
    async likeAnimal(){
        let name = this.ctx.request.query.name;
        let result = await this.ctx.service.animalService.likeAnimal(name);
        this.ctx.response.body = result;
    }
}
module.exports = animalController;