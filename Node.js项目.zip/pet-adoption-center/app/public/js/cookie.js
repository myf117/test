function getByKey(key) {
    let name = key + '=';
    let ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i].trim();
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return null;
}
function adopt(result) {
    let username = getByKey('username');
    if (username) {
        location.href = `./adopt.html?id=${result[i].id}`;
    } else {
        location.href = './login.html';
    }
}
//删除cookie中指定变量函数    
// function delCookie() {
    // document.cookie.username = '';
    // document.cookie = 'username=;expires=Thu, 01-Jan-1970 00:00:01 GMT';
// }
function delCookie(username) {
    var date = new Date();
    date.setTime(0);
    var str = username + "=" + encodeURIComponent('') + "; expires=" +     date.toGMTString()+"; path=/";
    document.cookie = str;
}
    