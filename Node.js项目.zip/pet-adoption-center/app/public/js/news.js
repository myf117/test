$(function () {
    var index = 0;//定义全局变量，记录li的号数
    setInterval(function () {
        index++;
        if (index == 7) {//当是第七个li时，执行
            $('#news ul').css('top', '0px');//将ul的top变为0
            index = 1;//再将号数变为1

        }
        var top = index * -30;//根据号数，计算向上移动多少
        $('#news ul').animate({ 'top': top + 'px' }, 500);//动态向上滑动
    }, 2000);

})
function showNews(result){
    let ul = document.querySelector('ul');
    for(let i = 0; i < result.length; i++){
        let li = document.createElement('li');
        let new_n = document.createElement('a');
        new_n.href = result[i].url;
        new_n.innerHTML = result[i].title;
        li.appendChild(new_n);
        ul.appendChild(li);
    }
    let li = document.createElement('li');
    let new_n = document.createElement('a');
    new_n.href = result[0].url;
    new_n.innerHTML = result[0].title;
    li.appendChild(new_n);
    ul.appendChild(li);
}
function news(){
    axios.get('/news.do', {

    }).then(res => {
        showNews(res.data);
    }).catch(err => {
        console.log(err);
        console.log('热点新闻ajax请求出错');
    })
}
news();