//获取当前登录用户的用户名
let username = getByKey('username');
let main = document.getElementById('main');
//点击左上角图标返回主页
main.onclick = function () {
    location.href = './main.html';
}
let login_a = document.getElementById('login-a');
login_a.innerHTML = username;
let adopt_a = document.getElementById('adopt-a');
//点击领养返回主页
adopt_a.onclick = function () {
    location.href = './main.html';
}
let baike_a = document.getElementById('baike_a');
baike_a.onclick = function () {
    location.href = './encyclopedia.html';
}
//退出到登录界面
function exit() {
    delCookie(username);
    location.href = '/public/login.html';
}
//判断当前登录账户是否是管理员，管理员可以对文件进行操作，用户只能传头像
let myBlog = document.getElementById('myBlog');
let myAdopt = document.getElementById('myAdopt');

//管理员
if (username == 'admin') {
    myAdopt.style.opacity = '0';
    myBlog.innerHTML = '文件管理';
    //管理员点击上传文件
    myBlog.onclick = function () {
        adminUpFile();

    }
    //普通用户
} else {
    myBlog.onclick = showBlog;

    myAdopt.onclick = function () {
        location.href = './living.html';
    }
}
function showBlog() {
    axios.get('/myBlog.do', {
        params: {
            upuser: username
        }
    }).then(res => {
        upBlog(username);
        showMyBlog(res.data);
    }).catch(err => {
        console.log(err);
        console.log('显示我的帖子ajax请求出错');
    })
}
let photo = document.getElementById('photo');
//从数据库返回个人信息
let myInf = document.getElementById('myInf');
function myInfShow() {
    console.log(username);
    axios.get('/myInf.do', {
        params: {
            name: username
        }
    }).then(res => {
        showMyInf(res.data);
    }).catch(err => {
        console.log(err);
        console.log('显示个人信息ajax请求出错');
    })
}
myInfShow();
myInf.onclick = myInfShow;
let set = document.getElementById('set');
let setting = document.getElementById('setting');
let showInf = document.getElementById('showInf');
let blog = document.getElementById('blog');
let upBlog1 = document.getElementById('upBlog');
//设置
set.onclick = function () {
    setting.style.display = 'block';
    showInf.style.display = 'none';
    blog.style.display = 'none';
    upFile.style.display = 'none';
    upBlog1.style.display = 'none';

    let modify = document.getElementById('modify');
    modify.onclick = function () {
        let modifyBox = document.getElementById('modifyBox');
        modifyBox.style.display = 'block';
        let sure = document.getElementById('sure');
        sure.onclick = function () {
            let newPwd = document.getElementById('newPwd').value;
            console.log(newPwd, newPwd.length);
            axios.get('/modify.do', {
                params: {
                    username: username,
                    pwd: newPwd
                }
            }).then(res => {
                if (res.data == '修改成功') {
                    console.log('修改密码成功');
                }
            }).catch(err => {
                console.log(err);
                console.log('修改密码ajax请求失败');
            })
        }
    }
    let exitCount = document.getElementById('exitCount');
    exitCount.onclick = exit;
}
//显示用户个人信息
function showMyInf(result) {
    showInf.style.display = 'block';
    setting.style.display = 'none';
    blog.style.display = 'none';
    upFile.style.display = 'none';
    upBlog1.style.display = 'none';
    let name = document.getElementById('name');
    name.innerHTML = `昵称：${username}`;
    let sex = document.getElementById('sex');
    sex.innerHTML = `性别：${result[0].sex}`;
    let address = document.getElementById('address');
    address.innerHTML = `位置：${result[0].address}`;
    let tell = document.getElementById('tell');
    tell.innerHTML = `电话：${result[0].tell}`;
    let myImg = document.getElementById('myImg');
    myImg.src = result[0].photo;
}
//上传并及时返回图片
let myFile = document.getElementById('myFile');
myFile.onchange = function () {
    let choose_file = myFile.files[0];
    let formData = new FormData();
    formData.append("uploadFile", choose_file, choose_file.name);
    const config = {
        headers: {
            "Content-Type": "multipart/form-data;boundary=" + new Date().getTime()
        }
    };
    let fType = choose_file.name.substring(choose_file.name.lastIndexOf('.') + 1);
    if (fType == 'jpg' || fType == 'png' || fType == 'jpeg' || fType == 'JPG') {
        let size = choose_file.size / 1024 / 1024;
        if (size > 2) {
            alert('文件不能超过2M');
            return false;
        }
        let reader = new FileReader();
        reader.readAsDataURL(choose_file);
        reader.onload = function () {
            let myImg = document.getElementById('myImg');
            myImg.setAttribute('src', this.result);
        }
        upMyFile(formData, config);
    }
    else {
        alert('文件格式不正确');
        return false;
    }
}
//上传文件到指定文件夹
function upMyFile(formData, config) {
    axios.post('/uploadFile.do', formData, config).then(res => {
        console.log('文件上传成功');
        console.log(res.data);
        upPhoto(res.data);

    }).catch(err => {
        console.log(err);
        console.log('上传文件ajax出错');
    })
}
//上传头像到数据库
function upPhoto(result) {
    axios.post('/upPhoto.do', {
        photo: result,
        username: username
    }).then(res => {
        console.log(res.data);
        console.log('上传头像成功');
    }).catch(err => {
        console.log(err);
        console.log('上传头像ajax请求出错');
    })
}
//显示帖子
function showMyBlog(result) {
    blog.style.display = 'block';
    showInf.style.display = 'none';
    setting.style.display = 'none';
    upFile.style.display = 'none';
    let title = document.getElementById('title');
    let content = document.getElementById('content');
    title.value = '';
    content.value = '';
    if (result.length == 0) {
        blog.innerHTML = '空空如也';
    } else {
        blog.innerHTML = '';
        for (let i = 0; i < result.length; i++) {
            let eBlog = document.createElement('div');
            eBlog.classList.add('eBlog');
            let title = document.createElement('h3');
            title.classList.add('title');
            title.innerHTML = result[i].title;
            eBlog.appendChild(title);
            let timer = document.createElement('p');
            timer.classList.add('timer');
            let time = `${result[i].timer}`.substring(0, 10);
            timer.innerHTML = time;
            eBlog.appendChild(timer);
            blog.appendChild(eBlog);
        }
    }
}
//发布帖子
function upBlog(username) {
    let upBlog = document.getElementById('upBlog');
    upBlog.style.display = 'block';

    let send = document.getElementById('send');
    send.onclick = function () {
        let title = document.getElementById('title').value;
        let content = document.getElementById('content').value;
        let timer = time();
        console.log(timer);
        axios.post('/upblog.do', {
            title: title,
            upuser: username,
            content: content,
            timer: timer,
            looker: 0
        }).then(res => {
            console.log(res.data);
            alert('帖子发布成功');
            showBlog();
        }).catch(err => {
            console.log(err);
            console.log('发布帖子ajax请求出错');
        })
    }

}
//格式化时间
function time() {
    //获取当前时间
    let timer = new Date();
    let year = timer.getFullYear();
    let month = check(timer.getMonth() + 1);
    let day = check(timer.getDate());
    let hours = check(timer.getHours());
    let minutes = check(timer.getMinutes());
    let seconds = check(timer.getSeconds());
    function check(key) {
        if (key < 10) {
            key = `0${key}`;
        }
        return key;
    }
    let time = `${year}-${month}-${day}` + ' '+ `${hours}:${minutes}:${seconds}`;
    return time;
}
//管理员上传文件
function adminUpFile() {
    let upFile = document.getElementById('upFile');
    upFile.style.display = 'block';
    setting.style.display = 'none';
    showInf.style.display = 'none';
    let lunbo = document.getElementById('lunbo');
    //上传轮播图图片
    lunbo.onchange = function () {
        let choose_file = lunbo.files[0];
        let formData = new FormData();
        formData.append("uploadFile", choose_file, choose_file.name);
        const config = {
            headers: {
                "Content-Type": "multipart/form-data;boundary=" + new Date().getTime()
            }
        };
        let fType = choose_file.name.substring(choose_file.name.lastIndexOf('.') + 1);
        if (fType == 'jpg' || fType == 'png' || fType == 'jpeg' || fType == 'JPG') {
            let size = choose_file.size / 1024 / 1024;
            if (size > 2) {
                alert('文件不能超过2M');
                return false;
            }
            let reader = new FileReader();
            reader.readAsDataURL(choose_file);
            reader.onload = function () {
                let lunbo_img = document.getElementById('lunbo_img');
                lunbo_img.setAttribute('src', this.result);
            }
            upLunbo(formData, config);
        }
        else {
            alert('文件格式不正确');
            return false;
        }

    }
    //上传百科文件
    let baike = document.getElementById('baike');

    baike.onchange = function () {
        let choose_file = baike.files[0];
        let formData = new FormData();
        formData.append("/upMyFile.do", choose_file, choose_file.name);
        const config = {
            headers: {
                "Content-Type": "multipart/form-data;boundary=" + new Date().getTime()
            }
        };
        let name = `${choose_file.name}`.substring(0, `${choose_file.name}`.indexOf('.'));
        upBaike(formData, config, name);
    }
}
//上传轮播图到指定位置
function upLunbo(formData, config) {
    axios.post('/uploadFile.do', formData, config).then(res => {
        console.log(res.data);
        upLunboToDB(res.data);
        console.log('轮播图图片上传成功');
    }).catch(err => {
        console.log(err);
        console.log('轮播图图片上传ajax请求出错');
    })
}
//上传轮播图到数据库
function upLunboToDB(url) {
    axios.post('/lunbo.do', {
        url: url
    }).then(r => {
        console.log(r.data);
        console.log('上传图片到数据库成功');
    }).catch(err => {
        console.log(err);
        console.log('上传图片到数据库ajax请求出错');
    })
}
//上传百科文件到指定位置
function upBaike(formData, config, name) {
    axios.post('/uploadFile.do', formData, config).then(res => {
        console.log(res.data);
        upBaikeToDb(name, res.data);
        console.log('上传百科文件成功');
    }).catch(err => {
        console.log(err);
        console.log('百科文件上传ajax请求出错');
    });
}
//上传百科文件到数据库
function upBaikeToDb(name, result) {
    let path = `${result}`.substring(`${result}`.indexOf('upFile'));
    path = `./${path}`;
    console.log(path);
    //问题2：读取上传的文件内容存到数据库，但是会乱码
    $.ajax({
        url: `${path}`,//这里是url
        method: 'GET',
        contentType: "application/x-www-form-urlencoded; charset=utf-8", 
        success: function (body, heads, status) {
            console.log(`${body}`.toString('utf-8'));  //body就是内容了，也就是url网页中的内容
            upbaike(name, body);
        }
    });
    // function loadXMLDoc(result) {
    //     let xmlhttp, tempStr;
    //     if (window.XMLHttpRequest) {
    //         xmlhttp = new XMLHttpRequest();
    //     } else {
    //         xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    //     }
    //     xmlhttp.onreadystatechange = function () {
    //         if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
    //             tempStr = xmlhttp.responseText;
    //             alert(tempStr);
    //             // var people = eval('(' + tempStr + ')');
    //             // alert(people.authors[0].lastName);
    //         }

    //     }
    //     xmlhttp.open("GET", result, false);
    //     xmlhttp.send();
    //     return tempStr;
    // }
    // let content = loadXMLDoc(result);
    // upbaike(name, content);
    let upbaike = function (name, content) {
        axios.post('/baike.do', {
            name: name,
            content: content
        }).then(r => {
            console.log(r.data);
            console.log('上传百科文件到数据库成功');
        }).catch(err => {
            console.log(err);
            console.log('上传百科文件到数据库ajax请求出错');
        })
    }

}