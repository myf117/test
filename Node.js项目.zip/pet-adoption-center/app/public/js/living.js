let url = decodeURI(location.search, 'utf-8').substring(1);
let aId = Number(url.substring(url.indexOf('=') + 1));
// let username = getByKey('username');
let username = getByKey('username');
let regist_a = document.getElementById('regist-a');
let login_a = document.getElementById('login-a');
let main = document.getElementById('main');
let table = document.querySelector('table');
main.onclick = function () {
    location.href = './main.html';
}
if (username) {
    login_a.innerHTML = username;
    regist_a.innerHTML = '退出';
    login_a.onclick = function () {
        axios.get('/user.do', {
            params: {
                name: username
            }
        }).then(res => {
            console.log(res.data);
            if (res.data.length == 1) {
                location.href = `./userCenter.html`;
            }
        }).catch(err => {
            console.log('进入个人中心ajax请求失败');
        })
    }
} else {
    login_a.onclick = function () {
        location.href = '/public/login.html';
    }

}
regist_a.onclick = function () {
    location.href = './login.html';
}
function regist() {
    location.href = '/public/login.html';
}
function encyclopedia() {
    location.href = './encyclopedia.html';
}
function showTable(result) {
    table.innerHTML = "<tr><th>选择</th><th>帖子</th><th>上传者</th><th>上传时间</th><th>操作</th></tr>";
    for (let i = 0; i < result.length; i++) {
        let tr = document.createElement('tr');
        let td_1 = document.createElement('td');
        let check = document.createElement('input');
        check.type = 'checkBox';
        check.classList.add('check');
        td_1.appendChild(check);
        tr.appendChild(td_1);
        let td_2 = document.createElement('td');
        td_2.classList.add('title');
        td_2.innerHTML = result[i].title;
        tr.appendChild(td_2);
        let td_3 = document.createElement('td');
        td_3.innerHTML = result[i].upuser;
        tr.appendChild(td_3);
        let td_4 = document.createElement('td');
        td_4.style.width = '100px'
        let time = `${result[i].timer}`.substring(0,10);
        td_4.innerHTML = `${time}`;
        tr.appendChild(td_4);
        let td_5 = document.createElement('td');
        td_5.style.width = '100px';
        let look = document.createElement('button');
        look.classList.add('look');
        look.style.marginRight = '10px';
        look.innerHTML = '查看';
        td_5.appendChild(look);
        let del = document.createElement('button');
        del.classList.add('del');
        del.innerHTML = '删除';
        td_5.appendChild(del);
        tr.appendChild(td_5);
        table.appendChild(tr);
    }
    let check = document.getElementsByClassName('check');
    let look = document.getElementsByClassName('look');
    let del = document.getElementsByClassName('del');
    // let title = document.getElementsByClassName('title');
    for (let i = 0; i < result.length; i++) {
        check[i].onclick = function () {
            check[i].cheched = 'checked';
        }
        look[i].onclick = function () {
            console.log(result[i].adopt_id);
            location.href = `./adopt.html?${result[i].adopt_id}`;
        }
        del[i].onclick = function (e) {
            axios.get('/delLive.do', {
                params: {
                    lId: result[i].id
                }
            }).then(res => {
                console.log('删除成功');
                del[i].parentElement.parentElement.innerHTML = '';
            }).catch(err => {
                console.log(err);
                console.log('删除预定ajax请求失败');
            })
        }
    }
}

function insertLive() {
    axios.get('/insertLive.do', {
        params: {
            aId: aId,
            username: username
        }
    }).then(res => {
        selectLive();
    }).catch(err => {
        console.log(err);
        console.log('加入预定表ajax请求失败');
    })
}
insertLive();
function selectLive() {
    axios.get('/selectLive.do', {
        params: {
            username: username
        }
    }).then(res => {
        table.innerHTML = '';
        showTable(res.data);
    }).catch(err => {
        console.log(err);
        console.log('查找所有预定ajax请求失败');
    })
}
selectLive();
let back = document.getElementById('back');
back.onclick = function() {
    location.href = `./adopt.html?id=${aId}`;
}