let url = decodeURI(location.search, 'utf-8').substring(1);
let id = Number(url.substring(url.indexOf('=') + 1));
let blogTitle;
function adoptInf() {
    axios.get('/adoptContent.do', {
        params: {
            id: id
        }
    }).then(res => {
        show(res.data);
        blogTitle = res.data[0].title;
        getMessage(blogTitle);
    }).catch(err => {
        console.log('showAdoptInf--ajax请求失败');
    })
}
function show(result) {
    
    // let adoptInf = document.getElementById('adoptInf');

    let h3 = document.querySelector('h3');
    h3.innerHTML = `#${result[0].title}`;

    let upuser = document.getElementsByClassName('upuser')[0];
    upuser.innerHTML = `发布者：${result[0].upuser}`;

    let content = document.getElementsByClassName('content')[0];
    content.innerHTML = result[0].content;

    let looker = document.getElementsByClassName('looker')[0];
    looker.innerHTML = `${result[0].looker}人看过`;
    looker.onclick = function () {
        axios.get('/looker.do', {
            params: {
                id: id,
                looker: result[0].looker
            }

        }).then(res => {
            looker.innerHTML = `${result[0].looker + 1}人看过`;
        }).catch(err => {
            console.log('浏览增加ajax请求出错');
        })
    }

    let timer = document.getElementsByClassName('timer')[0];
    let time = result[0].timer.substring(0, 10);
    timer.innerHTML = `发布于：${time}`;
}
adoptInf();
function living() {
    location.href = `./living.html?id=${id}`;
    
}
function showMessage(result){
    let messageBox = document.getElementsByClassName('message-box')[0];
    messageBox.innerHTML = '';
    for(let i = 0; i < result.length; i++){
        let messageN = document.createElement('div');
        messageN.classList.add('message-n');
        let messageTop = document.createElement('div');
        messageTop.classList.add('message-top');
        let messager = document.createElement('span');
        messager.innerHTML = `评论者：${result[i].name}`;
        messageTop.appendChild(messager);
        let timer = document.createElement('span');
        let time = result[i].timer.substring(0,10);
        timer.innerHTML = `评论时间：${time}`;
        messageTop.appendChild(timer);
        messageN.appendChild(messageTop);
        let messageContent = document.createElement('p');
        messageContent.classList.add('message-content');
        messageContent.innerHTML = result[i].content;
        messageN.appendChild(messageContent);
        let messageBottom = document.createElement('div');
        messageBottom.classList.add('message-bottom');
        let a1 = document.createElement('a');
        messageBottom.appendChild(a1);
        let back = document.createElement('a');
        let backImg = document.createElement('img');
        backImg.src = './img/message.png';
        back.appendChild(backImg);
        messageBottom.appendChild(back);
        let good = document.createElement('a');
        let goodImg = document.createElement('img');
        goodImg.src = './img/zan.png';
        good.appendChild(goodImg);
        messageBottom.appendChild(good);
        messageN.appendChild(messageBottom);
        messageBox.appendChild(messageN);
    }
}
// showMessage([1,1,1]);

function getMessage(blogTitle){
    console.log(1);
    axios.get('/message.do',{
        params: {
            id: id,
            title: blogTitle
        }
    }).then(res => {
        showMessage(res.data);
    }).catch(err => {
        console.log('显示评论ajax请求出错');
    })
}
function messages(){
    let upMessage = document.getElementById('upMessage');
    upMessage.style.display = 'block';
    let send = document.getElementById('send');
    send.onclick = function () {
        let mscontent = document.getElementById('mscontent').value;
        let timer = time();
        upMessage.style.display = 'none';
        axios.get('/upMessage.do', {
            params: {
                name: username,
                timer: timer,
                content: mscontent,
                user_id: id
            }
        }).then(res => {
            console.log(1);
            getMessage(res.data[0].title);
        }).catch(err => {
            console.log(err);
            console.log('评论ajax请求错误');
        })
    }
}
//格式化时间
function time() {
    //获取当前时间
    let timer = new Date();
    let year = timer.getFullYear();
    let month = check(timer.getMonth() + 1);
    let day = check(timer.getDate());
    let hours = check(timer.getHours());
    let minutes = check(timer.getMinutes());
    let seconds = check(timer.getSeconds());
    function check(key) {
        if (key < 10) {
            key = `0${key}`;
        }
        return key;
    }
    let time = `${year}-${month}-${day}` + ' '+ `${hours}:${minutes}:${seconds}`;
    return time;
}
