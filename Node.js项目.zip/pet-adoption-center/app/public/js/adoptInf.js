function adoptInf() {

    axios.get('/showAdoptInf.do', {

    }).then(res => {
        let container = document.getElementById('container');
        container.style.height = '800px';
        show(res.data);
    }).catch(err => {
        console.log('showAdoptInf--ajax请求失败');
    })
}


function findMore(){
    let inf = document.getElementById('adoptInf');
    inf.innerHTML = '';
    axios.get('/more.do', {

    }).then(res => {
        let container = document.getElementById('container');
        container.style.height = '2000px';
        show(res.data);
    }).catch(err => {
        console.log('查看更多ajax请求出错');
    })
}
function show(result) {
    let adoptInf = document.getElementById('adoptInf');
    for (let i = 0; i < result.length; i++) {
        let adopt = document.createElement('div');
        adopt.classList.add('adopt');
        let img = document.createElement('img');
        img.src = './img/logo-4.png';
        adopt.appendChild(img);
        let inf = document.createElement('div');
        inf.classList.add('inf');
        let inf_top = document.createElement('a');
        inf_top.classList.add('inf-top');
        inf_top.innerHTML = result[i].title;
        inf.appendChild(inf_top);
        let inf_bottom = document.createElement('div');
        inf_bottom.classList.add('inf-bottom');
        let upuser = document.createElement('a');
        upuser.classList.add('upuser');
        upuser.innerHTML = `发布者：${result[i].upuser}`;
        inf_bottom.appendChild(upuser);
        let timer = document.createElement('p');
        let time = result[i].timer.substring(0,10);
        timer.innerHTML = `发布时间：${time}`;
        inf_bottom.appendChild(timer);
        let looker = document.createElement('a');
        looker.classList.add('looker');
        looker.innerHTML = `${result[i].looker}人看过`;
        inf_bottom.appendChild(looker);
        inf.appendChild(inf_bottom);
        adopt.appendChild(inf);
        adoptInf.appendChild(adopt);

    }
    let inf_top = document.getElementsByClassName('inf-top');
    let upuser = document.getElementsByClassName('upuser');
    let looker = document.getElementsByClassName('looker');
    for (let i = 0; i < result.length; i++) {
        inf_top[i].onclick = content;
        upuser[i].onclick = function () {
            location.href = './upuser.html';
        }
        looker[i].onclick = content;
        function content() {
            // adopt();
            let username = getByKey('username');
            if(username){
                location.href = `./adopt.html?id=${result[i].id}`;
            }else {
                location.href = './login.html';
            }
            
        }
    }
}