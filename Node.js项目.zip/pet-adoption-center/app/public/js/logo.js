let img_1 = document.getElementsByClassName('img-1')[0];
let img_2 = document.getElementsByClassName('img-2')[0];
img_2.style.display = 'none';
let logo = document.getElementById('logo');
logo.addEventListener = ('mouseenter', function () {
    img_1.style.display = 'none';
    img_2.style.display = 'inline-block';
});
logo.addEventListener = ('mouseOut', function () {
    img_2.style.display = 'none';
    img_1.style.display = 'inline-block';
});