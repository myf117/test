let conLeft = document.getElementById('container-left');
function showAnimal(result){
    conLeft.innerHTML = '';
    for(let i = 0; i < result.length; i++){
        let animal = document.createElement('div');
        animal.classList.add('animal');
        let animalLeft = document.createElement('div');
        animalLeft.classList.add('animal-left');
        let animalImg = document.createElement('img');
        animalImg.src = './img/logo-4.png';
        animalLeft.appendChild(animalImg);
        animal.appendChild(animalLeft);
        let animalRight = document.createElement('div');
        animalRight.classList.add('animal-right');
        let h2 = document.createElement('h2');
        h2.innerHTML = result[i].name;
        animalRight.appendChild(h2);
        let p = document.createElement('p');
        p.innerHTML = result[i].content;
        animalRight.appendChild(p);
        animal.appendChild(animalRight);
        conLeft.appendChild(animal);
    }
}
function animal(){
    axios.get('/animal.do', {

    }).then(res => {
        showAnimal(res.data);
        parentClick();
    }).catch(err => {
        console.log(err);
        console.log('动物百科ajax请求失败');
    })
}
animal();
function parentClick(){
    let containerRight = document.getElementById('container-right');
    containerRight.onclick = function(e){
        if(e.target.innerHTML == '猫' ||e.target.innerHTML == '兔' || e.target.innerHTML == '鼠' || e.target.innerHTML == '犬'){
            likeAnimal(e.target.innerHTML);
        }
        
        console.log(e.target.innerHTML);
    }
}
function likeAnimal(name){
    axios.get('/likeAnimal.do', {
        params: {
            name: name
        }
    }).then(res => {
        
        showAnimal(res.data);
    }).catch(err => {
        console.log(err);
        console.log('分类显示ajax请求出错');
    })
}
