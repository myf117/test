let ocont = document.getElementById("container");
//点击外框，new个主题烟花
ocont.onclick = function (eve) {
    let e = eve || window.event;
    //new一个烟花类的实例化对象
    new Fire({
        //用语法糖的方式传入参数
        //传入一个对象
        cont: ocont,
        x: e.clientX - this.offsetLeft - 5,//获取鼠标点击的位置在背景div中的坐标
        y: e.clientY - this.offsetTop - 5
    });
}
//定义烟花类
class Fire {
    constructor(options) {
        this.cont = options.cont;
        this.x = options.x;
        this.y = options.y;
        this.f = document.createElement("div");//点击时出现的一个向上的烟花子弹
        this.init();
    }
    init() {
        this.f.className = "fire";
        this.cont.appendChild(this.f);
        this.f.style.background = randomColor();
        this.f.style.left = this.x + "px";
        this.move();
    }
    move() {
        //大烟花从先到达鼠标的位置然后，消失，生成无数个各个方向飞的小烟花
        move(this.f, {
            top: this.y
        }, () => {
            this.f.remove();
            this.smallFire();
        })

    }
    smallFire() {
        let num = random(10, 20); //小烟花的个数
        let r = random(100, 200) //小烟花的半径
        for (let i = 0; i < num; i++) {
            let s = document.createElement("div"); //构造小烟花
            s.className = "small-fire";
            s.style.left = this.x + "px"; //以点击位置为中心
            s.style.top = this.y + "px";
            s.style.background = randomColor();
            this.cont.appendChild(s);
            let target = {
                x: parseInt(Math.sin(Math.PI / 180 * (360 / num * i)) * r) + this.x,
                //360 / num两个烟花之间的夹角,360 / num * i以夹角围成一个圈,
                y: parseInt(Math.cos(Math.PI / 180 * (360 / num * i)) * r) + this.y
            }

            move(s, {
                left: target.x,
                top: target.y
            }, () => {
                s.remove();
            })
        }
    }

}
function random(a, b) {
    //用于随机生成烟花半径和炸开的烟花个数
    return Math.round(Math.random() * (a - b) + b)
}

function randomColor() {
    //随机生成烟花颜色
    return `rgb(${random(0, 255)},${random(0, 255)},${random(0, 255)})`;
}

function move(ele, data, end) {
    clearInterval(ele.t);
    ele.t = setInterval(() => {
        // 1.计时器开启之后，设定状态为关闭计时器
        let onoff = true;
        for (let i in data) {
            let iNow = parseInt(getStyle(ele, i));
            let speed = (data[i] - iNow) / 7;
            speed = speed < 0 ? Math.floor(speed) : Math.ceil(speed);
            // 必须所有属性都到目标才能清计时器
            // 每次只能拿到一个属性
            // 如果有一个属性没到目标，一定不清除计时器

            if (data[i] != iNow) {
                // 3.但是在设定状态之后，关闭计时器之前，判断是否有属性没到目标，只要有一个属性没到目标，就把状态改成不关闭计时器
                onoff = false;
            }
            ele.style[i] = iNow + speed + "px";
        }
        // 2.根据状态决定关闭计时器
        if (onoff) {
            clearInterval(ele.t);
            end && end();
        }
    }, 30);
}
//获取非行内样式元素属性兼容
function getStyle(ele, attr) {
    if (getComputedStyle) {
        return getComputedStyle(ele, false)[attr]; //其他浏览器，只能获取不能设置
    } else {
        return ele.currentStyle[attr]; //IE，只能获取不能设置
    }
}