//格式化时间
function time() {
    //获取当前时间
    let timer = new Date();
    let year = timer.getFullYear();
    let month = check(timer.getMonth() + 1);
    let day = check(timer.getDate());
    let hours = check(timer.getHours());
    let minutes = check(timer.getMinutes());
    let seconds = check(timer.getSeconds());
    function check(key) {
        if (key < 10) {
            key = `0${key}`;
        }
        return key;
    }
    let time = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    return time;
}