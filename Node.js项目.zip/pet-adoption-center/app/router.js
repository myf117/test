module.exports = app => {
    const {router, controller} = app;
    router.post('/login.do', controller.loginController.login);
    router.post('/regist.do', controller.registController.regist);
    router.get('/showAdoptInf.do', controller.showAdoptController.show);
    router.get('/more.do', controller.showAdoptController.more);
    router.get('/user.do', controller.showAdoptController.user);
    router.get('/news.do', controller.showAdoptController.news);
    router.get('/getLunbo.do', controller.showAdoptController.getLunbosrc);
    router.get('/adoptContent.do', controller.adoptContentController.content);
    router.get('/looker.do', controller.adoptContentController.looker);
    router.get('/message.do', controller.adoptContentController.message);
    router.get('/upMessage.do', controller.adoptContentController.upMessage);
    router.get('/animal.do', controller.animalController.showAllAnimal);
    router.get('/likeAnimal.do', controller.animalController.likeAnimal);
    router.get('/insertLive.do', controller.livingController.insertLive);
    router.get('/selectLive.do', controller.livingController.selectLive);
    router.get('/delLive.do', controller.livingController.delLive);
    router.get('/myInf.do', controller.userCenterController.myInf);
    router.get('/myBlog.do', controller.userCenterController.myBlog);
    router.get('/modify.do', controller.userCenterController.modify);
    router.post('/upblog.do', controller.userCenterController.upBlog);
    router.post('/uploadFile.do', controller.upFileController.upFile);
    router.post('/upPhoto.do', controller.upFileController.upPhoto);
    router.post('/lunbo.do', controller.upFileController.lunbo);
    router.post('/baike.do', controller.upFileController.baike);
}