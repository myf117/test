exports.cluster = {
    listen: {
        port: 8000,
        // hostname: '192.168.6.53', // 不建议设置 hostname 为 '0.0.0.0'，它将允许来自外部网络和来源的连接，请在知晓风险的情况下使用
        // path: '/var/run/egg.sock',
        // hostname: '192.168.43.38',
        // hostname: '192.168.6.24',
        hostname: '0.0.0.0'
        // hostname: '127.0.0.1'
    }
}