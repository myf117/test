exports.mysql = {//使用数据库要配置好这个文件
	enable: true,
	package: 'egg-mysql',
}
exports.cors = {
	enable: true,
	package: 'egg-cors',
};